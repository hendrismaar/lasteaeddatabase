﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Sicknote
    {
        [ForeignKey("Id")]
        [Key]
        public Guid Id { get; set; }
        public string Reason { get; set; }
        public string Frequency { get; set; }
        public DateTime Beginning { get; set; }
        public DateTime Ending { get; set; }
    }
}
